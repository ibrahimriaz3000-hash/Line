package com.dynamicpill.module;

import android.app.Application;
import android.content.Context;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {
    private static boolean started = false;

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;
        try {
            XposedHelpers.findAndHookMethod(android.view.View.class, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        android.view.View v = (android.view.View) param.thisObject;
                        String cn = v.getClass().getName();
                        if (cn.contains("KeyguardStatusBarView")) {
                            PillController.registerKeyguardBar(v);
                            return;
                        }
                        String lcn = cn.toLowerCase();
                        if (lcn.contains("controlcenter")) {
                            PillController.registerControlCenter(v);
                        }
                        if (lcn.contains("securitycontainer") || lcn.contains("bouncer")
                                || lcn.contains("keyguardhostview")) {
                            PillController.registerBouncer(v);
                        }
                        if (v.getId() == android.view.View.NO_ID) return;
                        String n = v.getResources().getResourceEntryName(v.getId());
                        if ("keyguard_header".equals(n)) PillController.registerKeyguardBar(v);
                        else if ("status_bar_contents".equals(n)) PillController.registerBar(v, true);
                        else if ("status_bar".equals(n)) PillController.registerBar(v, false);
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: bar hook failed: " + t);
        }
        try {
            PillController.hookStatusBarHeight(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: status bar height hook failed: " + t);
        }
        try {
            PillController.hookShadeWindow(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: shade window hook failed: " + t);
        }
        try {
            PillController.hookStatusBarState(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: state hook failed: " + t);
        }
        try {
            PillController.hookKeyguardManager(lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: keyguard manager hook failed: " + t);
        }
        try {
            XposedHelpers.findAndHookMethod(Application.class, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Context ctx = (Context) param.thisObject;
                        if (!"com.android.systemui".equals(ctx.getPackageName())) return;
                        if (started) return;
                        started = true;
                        new PillController(ctx).start();
                    } catch (Throwable t) {
                        XposedBridge.log("DynamicPill: start failed: " + t);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: hook failed: " + t);
        }
    }
}
